class SupabaseException(Exception):
    pass
